# Toxic Waste
## Recipes also make useless Scrap

This simple mod changes the game in a big way- most recipes will now produce additional useless scrap. You have 2 ways of dealing with this avalanche of garbage

- The Flare Stack mod adds incenerators that turn Scrap into a lot of pollution quickly.
- The Garbagefill item (similar to the Landfill) can be used to sequester Scrap into the map itself. These Garbagefills will slowly emit pollution forever and is flammable.
- The Garbage Tomb can be built over Garbagefill. It is an enourmous 9x9 that cannot be mined or destroyed. 
