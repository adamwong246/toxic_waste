-- I'm not sure what this ought to be
local garbageMask = {
"ground-tile",

-- "water-tile",
-- -- -- "resource-layer",
-- -- -- "doodad-layer",
-- "floor-layer",
-- "item-layer",
-- "object-layer",
"colliding-with-tiles-only"
}

local sacrificeMask = {
  "ground-tile",
  "water-tile",
  -- -- -- "resource-layer",
  -- -- -- "doodad-layer",
  "floor-layer",
  "item-layer",
  "object-layer",
  "colliding-with-tiles-only"
}

local redTint = {0.80, 0.25, 0.25, 0.8}
local darkRedTint = {1, 0.1, 0.5, 1}

local garbagefillItem =   {
    type = "item",
    name = "garbagefill",
    icons = {{
      icon = "__base__/graphics/icons/landfill.png",
      tint = redTint
    }},
    icon_size = 64, icon_mipmaps = 4,
    subgroup = "terrain",
    order = "c[landfill]-a[dirt]",
    stack_size = 100,
    place_as_tile =
    {
      result = "garbagefill",
      condition_size = 1,
      condition = garbageMask
    }
  }

  local sacrificefillItem =   {
    type = "item",
    name = "sacrificefill",
    icons = {{
      icon = "__base__/graphics/icons/landfill.png",
      tint = darkRedTint
    }},
    icon_size = 64, icon_mipmaps = 4,
    subgroup = "terrain",
    order = "c[landfill]-a[dirt]",
    stack_size = 100,
    place_as_tile =
    {
      result = "sacrificefill",
      condition_size = 1,
      condition = sacrificeMask
    }
  }

local garbagefillRecipe = {
    type = "recipe",
    name = "garbagefill",
    energy_required = 0.5,
    enabled = true,
    category = "crafting",
    ingredients =
    {
      {"scrap", 100}
    },
    result= "garbagefill",
    result_count = 1
}

local sacrificefillRecipe = {
  type = "recipe",
  name = "sacrificefill",
  energy_required = 0.5,
  enabled = true,
  category = "crafting",
  ingredients =
  {
    {"scrap", 100}
  },
  result= "sacrificefill",
  result_count = 1
}

local garbagefillTile = table.deepcopy(data.raw["tile"]["landfill"])
garbagefillTile.name = "garbagefill"
garbagefillTile.tint = redTint
garbagefillTile.pollution_absorption_per_second = -0.001
garbagefillTile.collision_mask = garbageMask
garbagefillTile.destructible = false;
garbagefillTile.walking_speed_modifier = 0.3;
-- If you want the tile to not be mineable, don't specify the minable property.
-- garbagefillTile.minable = false;

local sacrificefillTile = table.deepcopy(data.raw["tile"]["landfill"])
sacrificefillTile.name = "sacrificefill"
sacrificefillTile.tint = darkRedTint
sacrificefillTile.pollution_absorption_per_second = -0.01
sacrificefillTile.collision_mask = sacrificeMask
sacrificefillTile.destructible = false;
sacrificefillTile.walking_speed_modifier = 0.05;
-- If you want the tile to not be mineable, don't specify the minable property.
-- garbagefillTile.minable = false;



data:extend{
    garbagefillItem, garbagefillRecipe, garbagefillTile,
    sacrificefillItem, sacrificefillRecipe, sacrificefillTile,
}
