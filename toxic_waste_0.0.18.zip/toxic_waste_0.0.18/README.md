This cursed mod alters most of the recipes in the game so that they produce 1 additional scrap. You can sequester it a variety of ways.

## New items
- Scrap: this clutter can't be stacked and will turn into SacrificeZone if destroyed or dropped on the ground.
- Garbagefill: Pollluting tiles which can be paved over to negate their polluting effects.
- SacrificeZone: Pollluting tiles which can't be paved over!
