local redTint = {0.9, 0.25, 0.5, 0.8}

local voidingMachine = table.deepcopy(data.raw["furnace"]["stone-furnace"])
voidingMachine.energy_source = {
    type = "void"
};
voidingMachine.name = "Voiding Machine";
voidingMachine.localised_name = "Voiding Machine";

voidingMachine.icons= {
  {
    icon=voidingMachine.icon,
    tint=redTint
  },
}

local voidingMachineRecipe = table.deepcopy(data.raw["recipe"]["stone-furnace"])
voidingMachineRecipe.name = "Voiding Machine"
voidingMachineRecipe.localised_name = "Voiding Machine";
-- voidingMachineRecipe.icons= {
--   {
--     icon=voidingMachineRecipe.icon,
--     tint={r=1,g=0,b=0,a=0.3}
--   },
-- }

data:extend{voidingMachine, voidingMachineRecipe};
