local mask = {"ground-tile", -- "water-tile",
-- -- -- "resource-layer",
-- -- -- "doodad-layer",
-- "floor-layer",
-- "item-layer",
-- "object-layer",
"colliding-with-tiles-only"}


local blackTint = {1, 1, 1, 0.7}

local voidfillItem = {
    type = "item",
    name = "voidfill",
    icons = {{
        icon = "__base__/graphics/icons/blueprint.png",
        tint = redTint
    }},
    icon_size = 64,
    icon_mipmaps = 4,
    subgroup = "terrain",
    order = "c[landfill]-a[dirt]",
    stack_size = 100,
    place_as_tile = {
        result = "voidfill",
        condition_size = 1,
        condition = mask
    }
}

local voidfillRecipe = {
    type = "recipe",
    name = "voidfill",
    energy_required = 0.5,
    enabled = true,
    category = "crafting",
    ingredients = {{"scrap", 1}},
    result = "voidfill",
    result_count = 1
}


local voidfillTile = table.deepcopy(data.raw["tile"]["out-of-map"])
voidfillTile.name = "voidfill"
voidfillTile.tint = blackTint
voidfillTile.pollution_absorption_per_second = 0
voidfillTile.collision_mask = mask
voidfillTile.destructible = false;
voidfillTile.walking_speed_modifier = 0;

data:extend{voidfillItem, voidfillRecipe, voidfillTile}