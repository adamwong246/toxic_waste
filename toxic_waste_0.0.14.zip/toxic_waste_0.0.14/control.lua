function died(event)
  log('died');
  log(serpent.block(event.entity.get_inventory(defines.inventory.chest).get_contents()));
end

function dropped(event)
  log('droped');
  log(event.entity.prototype.name);
  log(event.entity.prototype.type);
end

script.on_event(defines.events.on_entity_died, died)
script.on_event(defines.events.on_player_dropped_item, dropped)