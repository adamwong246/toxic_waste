1) All physical recipes produce extra Scrap and all fluid recipes produce an extra Sludge.

2) You can sequester this clutter in a varitey of ways.

- Garbagefill: Pollluting tiles which can be paved over to negate their polluting effects.
- SacrificeZone: Pollluting tiles which can't be paved over!
